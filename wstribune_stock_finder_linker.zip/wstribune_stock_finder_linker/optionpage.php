<?php
        load_plugin_textdomain('wst_stock_links', 'wp-content/plugins/wstribune_stock_finder_linker');
        include_once('wstribune_stock_finder_linker.php');
        wp_nonce_field('update-options') ;

        if ('process' == $_POST['stage']) {
                 update_option('wst_stock_links_filter_words_list', $_POST['filter_words_list']);

        }

        /* Get options for form fields */
        $filter_words_list = get_option('wst_stock_links_filter_words_list');


?>

<div class="wrap">
  <h2><?php _e('wstribune.com Stock Ticker Links Options') ?></h2>
  <form name="form1" method="post" >

    <input type="hidden" name="stage" value="process" />

    <p class="submit">
      <input type="submit" name="Submit" value="<?php _e('Save Options') ?> &raquo;" />
    </p>

    <strong>List of tickers or symbols that should be not be linked by the plugin</strong><br />
    <p>Use comma to seperate the ticker/symbols. For example, "XOM, MSFT, FB, GOOG,ETF,ROI,SEC,KO"</p>
    <textarea id="filter_words_list" name="filter_words_list" rows="10" cols="54"><?php echo get_option('WST_stock_links_filter_words_list'); ?></textarea>
	
    <p class="submit">
      <input type="submit" name="Submit" value="<?php _e('Save Options') ?> &raquo;" />
    </p>
  </form>

</div>
