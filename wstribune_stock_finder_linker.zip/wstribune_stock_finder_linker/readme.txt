WSTribune.com Stock Finder and Linker Plugin for Wordpress

Contributors: wstribune.com
Tags: stocks, equities, symbols, finance, markets, mutual funds, ETFs, tickers, links, investing, investment
Developed for Wordpress: Version 2.3 and above



== Overview ==

This is a simple plugin which essentially looks inside your Wordpress posts for stock symbols: It automatically finds stock symbols e.g. MSFT (Microsoft) or XOM (ExxonMobil) and links them to the overview page for each stock on wstribune.com where the stock price, trends and market news for that stock are provided. 


In order to install this plugin, simply upload the zip file for the plugin to your wordpress installation and activate it. 

You can check out more information about the look and feel of this plugin check out this link: http://markets.wstribune.com/wstribune 


== Installation Instructions ==

1. Upload 'wstribune_stock_finder_linker' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. When you write your article, include stock symbols in parenthesis -- e.g., (MSFT) or (XOM)
4. When the post is published, all tickers will be linked to the research page on wstribune.com




Note: We used a free piece of code by Investor Guide to develop this plugin. 