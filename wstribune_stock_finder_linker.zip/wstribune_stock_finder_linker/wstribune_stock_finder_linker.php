<?php
/*
Plugin Name: wstribune.com Stock finder and linker
Plugin URI: http://www.wstribune.com/ 
Author: wstribune.com
Overview: A simple plugin to find the stock symbols like (XOM) or (MSFT) automatically and link them to stock price and market news page for that stock on <a href="http://www.wstribune.com/">wstribune.com</a>.
*/


add_action('admin_menu','wst_stock_link_setting_options');
$filterwords = get_option('wst_stock_links_filter_words_list');


function link_ticker ($content) {

   global $filterwords;

   if ($filterwords != "") {
	$filterwords = explode (",",$filterwords);

	foreach ($filterwords as $filterword) {
	   $filterword = trim($filterword);
	   $replaceword = "(<acronym>".$filterword."</acronym>)";
	   $filterword = "(".$filterword.")";

	   $content = str_replace ($filterword, $replaceword, $content);
	}
   }

   $content =
      preg_replace (
         '/ \(((?:[0-9]+(?=[a-z])|(?![0-9\.\:\_\-]))(?:[a-z0-9]|[\_\.\-\:](?![\.\_\.\-\:]))*[a-z0-9]+)\)/i',
         " (<a href=\"http://markets.wstribune.com/wstribune./quote?Symbol=$1\" class=\"ticker\" target=\"_blank\">$1</a>)",
         $content
         );

     return $content;
}

add_filter ('the_content', 'link_ticker');
add_filter ('the_content_limit', 'link_ticker');
add_filter ('the_content_rss', 'link_ticker');

//add_filter ('the_excerpt_rss', 'link_ticker');
//add_filter ('the_excerpt', 'link_ticker');


function wst_stock_link_setting_options(){
	add_options_page('WST Stock Links', 'WST Stock Links', 5, 'wstribune_stock_finder_linker/optionpage.php');
}

?>
